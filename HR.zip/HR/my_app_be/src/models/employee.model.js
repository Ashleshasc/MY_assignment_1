'use strict';
var dbConn = require('./../../config/db.config');

var Employee = function (employee) {
    this.emp_code = employee.emp_code;
    this.name = employee.name;
    this.dept = employee.dept;
    this.gender = employee.gender;
    this.dob = employee.dob;
    this.joining_date = employee.joining_date;
    this.prev_exp = employee.prev_exp;
    this.salary = employee.salary;
    this.address = employee.address
};

Employee.create = function (newEmp, result) {
    dbConn.query("INSERT INTO employees set ?", newEmp, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};

Employee.findById = function (id, result) {
    dbConn.query("Select * from employees where id = ? ", id, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);
        }
    });
};

Employee.findAll = function (result) {
    dbConn.query("Select * from employees", function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            console.log('employees : ', res);
            result(null, res);
        }
    });
};

Employee.update = function (id, employee, result) {
    dbConn.query("UPDATE employees SET emp_code=?,name=?,dept=?,gender=?,dob=?,joining_date=?,prev_exp=?, salary=?, address=? WHERE id = ?", [employee.emp_code, employee.name, employee.dept, employee.gender, employee.dob, employee.joining_date, employee.prev_exp, employee.salary, employee.address, id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};
Employee.delete = function (id, result) {
    dbConn.query("DELETE FROM employees WHERE id = ?", [id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};
module.exports = Employee;