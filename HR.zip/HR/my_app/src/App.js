import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import './App.css';
import AddEmployee from './component/addEmployee';
import EmployeeDetails from './component/employeeDetails';

function App() {
  return (
    <div className="App">
      <Router>
        <div>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/employee-details">Employee Details</Link>
            </li>
          </ul>
          <hr />
          <Switch>
            <Route exact path="/">
              <AddEmployee />
            </Route>
            <Route path="/employee-details">
              <EmployeeDetails />
            </Route>
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
