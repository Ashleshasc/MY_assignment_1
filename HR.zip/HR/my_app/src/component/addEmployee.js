import * as React from 'react';
import './employee.css';

export default function AddEmployee() {

    const [empCode, setEmpCode] = React.useState('')
    const [name, setName] = React.useState('')
    const [department, setDepartment] = React.useState('')
    const [gender, setGender] = React.useState('')
    const [dob, setDob] = React.useState('')
    const [JoiningDate, setJoiningDate] = React.useState('')
    const [previousExp, setPreviousExp] = React.useState(0)
    const [salary, setSalary] = React.useState(0)
    const [address, setAddress] = React.useState('')

    const handleSubmit = async () => {
        const data = {
            emp_code: empCode,
            name: name,
            dept: department,
            gender: gender,
            dob: dob,
            joining_date: JoiningDate,
            prev_exp: previousExp,
            salary: salary,
            address: address
        }
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        };
        try {
            const response = await fetch('/api/v1/employees', requestOptions);
            const data = await response.json();
            return data
        } catch (err) {
            console.log(err)
        }
    }

    return (
        <div className="form">
            <h1>Add Employee</h1>
            <div className="form-group">
                <label>Emp Code</label>
                <input type="text" onChange={(e) => setEmpCode(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Name</label>
                <input type="text" onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Department</label>
                <select name="departmewnt" onChange={(e) => setDepartment(e.target.value)}>
                    <option value="Admin">Admin</option>
                    <option value="Technology">Technology</option>
                    <option value="Accounts">Accounts</option>
                </select>
            </div>
            <div className="form-group">
                <label>Gender</label>
                <div>
                    <input type="radio" id="male" name="gender" value="male" onChange={(e) => setGender(e.target.value)} />
                    Male
                    <input type="radio" id="female" name="gender" value="female" onChange={(e) => setGender(e.target.value)} />
                    Female
                </div>
            </div>
            <div className="form-group">
                <label>DOB</label>
                <input type="date" onChange={(e) => setDob(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Joining Date</label>
                <input type="date" onChange={(e) => setJoiningDate(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Previous Experience</label>
                <input type="number" onChange={(e) => setPreviousExp(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Salary</label>
                <input type="number" onChange={(e) => setSalary(e.target.value)} />
            </div>
            <div className="form-group">
                <label>Address</label>
                <textarea rows="4" cols="39" onChange={(e) => setAddress(e.target.value)} />
            </div>
            <div className="form-group">
                <label></label>
                <div className="button-container">
                    <button className="button" onClick={() => handleSubmit()} disabled={!empCode && !name && !department && !dob && !gender && !JoiningDate && !previousExp && !salary && !address}>Submit</button>
                    <a href="/employee-details"><button className="button-reset">Cancel</button></a>
                </div>
            </div>
        </div>
    );
}