import React from "react";

function Modal(props) {
    const {userData} = props
    console.log(userData,"userData")
    const [empCode, setEmpCode] = React.useState('')
    const [name, setName] = React.useState('')
    const [department, setDepartment] = React.useState('')
    const [gender, setGender] = React.useState('')
    const [dob, setDob] = React.useState('')
    const [JoiningDate, setJoiningDate] = React.useState('')
    const [previousExp, setPreviousExp] = React.useState(0)
    const [salary, setSalary] = React.useState(0)
    const [address, setAddress] = React.useState('')

    const handleSubmit = () => {
        const data = {
            emp_code: empCode,
            name: name,
            dept: department,
            gender: gender,
            dob: dob,
            joining_date: JoiningDate,
            prev_exp: previousExp,
            salary: salary,
            address: address
        }

        props.updateEmployee(data);
    }

    if (props.isOpen === false)
        return null
    return (
        <div>
            <div className="modal">
                <div className="form">
                    <h1>Update Employee</h1>
                    <div className="form-group">
                        <label>Emp Code</label>
                        <input type="text" value={empCode} onChange={(e) => setEmpCode(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Name</label>
                        <input type="text" onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Department</label>
                        <select name="departmewnt" onChange={(e) => setDepartment(e.target.value)}>
                            <option value="Admin">Admin</option>
                            <option value="Technology">Technology</option>
                            <option value="Accounts">Accounts</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Gender</label>
                        <div>
                            <input type="radio" id="male" name="gender" value="male" onChange={(e) => setGender(e.target.value)} />
                            Male
                            <input type="radio" id="female" name="gender" value="female" onChange={(e) => setGender(e.target.value)} />
                            Female
                        </div>
                    </div>
                    <div className="form-group">
                        <label>DOB</label>
                        <input type="date" onChange={(e) => setDob(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Joining Date</label>
                        <input type="date" onChange={(e) => setJoiningDate(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Previous Experience</label>
                        <input type="number" onChange={(e) => setPreviousExp(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Salary</label>
                        <input type="number" onChange={(e) => setSalary(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label>Address</label>
                        <textarea rows="4" cols="39" onChange={(e) => setAddress(e.target.value)} />
                    </div>
                    <div className="form-group">
                        <label></label>
                        <div className="button-container">
                            <button className="button" onClick={() => handleSubmit()} disabled={!empCode && !name && !department && !dob && !gender && !JoiningDate && !previousExp && !salary && !address}>Submit</button>
                            <a href="/employee-details"><button className="button-reset">Cancel</button></a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg" onClick={() => props.onClose()} />
        </div>
    )
}

function EmployeeDetails() {

    const [data, setData] = React.useState(null);
    const [userData, setUserData] = React.useState(null);
    const [open, setModelState] = React.useState(false)
    const [userId , setUserId] = React.useState(null)

    React.useEffect(() => {
        fetchEmployee();
    }, []);

    const fetchEmployee = async () => {
        try {
            const response = await fetch("/api/v1/employees");
            const data = await response.json();
            setData(data)
        } catch (err) {
            console.log(err)
        }
    }

    const openModal = async (id) => {
        setUserId(id)
        try {
            const response = await fetch(`/api/v1/employees/${id}`);
            const data = await response.json();
            setUserData(data)
        } catch (err) {
            console.log(err)
        }
        setModelState(true)
    }

    const updateEmployee = async (data) => {
        const requestOptions = {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        };
        try {
            const response = await fetch(`/api/v1/employees/${userId}`, requestOptions);
            const data = await response.json();
            setModelState(false)
            fetchEmployee();
            return data
        } catch (err) {
            console.log(err)
        }
    }

    const closeModal = () => {
        setModelState(false)
    }

    return (
        <div>
            <h1 className="details-title">Details</h1>
            <table>
                <thead>
                    <tr>
                        <th>Emp Code</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Gender</th>
                        <th>DOB</th>
                        <th>Joining Date</th>
                        <th>Prev Exp</th>
                        <th>Salary</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data && data.map(item => {
                        return (
                            <tr key={item.id}>
                                <td>{item.emp_code}</td>
                                <td>{item.name}</td>
                                <td>{item.dept}</td>
                                <td>{item.gender}</td>
                                <td>{item.dob}</td>
                                <td>{item.joining_date}</td>
                                <td>{item.prev_exp}</td>
                                <td>{item.salary}</td>
                                <td>{item.address}</td>
                                <td className="edit" onClick={() => openModal(item.id)}>Edit</td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
            <Modal userId={userId} userData={userData} isOpen={open} onClose={() => closeModal()} updateEmployee={(data) => updateEmployee(data)}/>
        </div>
    );
}

export default EmployeeDetails;